"""Probability simplex projection and the six metrics in Table II."""

import numpy as np
from scipy.special import rel_entr


METRICS = ("chebyshev", "clark", "canberra", "kl", "cosine", "intersection")
KL_FLOOR = 1e-10


def proj(values):
    """Exact Duchi et al. (ICML 2008) sorting/threshold simplex projection.

    Each row is sorted in descending order, the simplex support is determined
    by prefix sums, and the corresponding offset is subtracted and clipped.
    """
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 2 or values.shape[1] == 0 or not np.isfinite(values).all():
        raise ValueError("Simplex projection needs a finite matrix with at least one column.")

    # Translation preserves the projection. Values below max - 1 have zero mass.
    with np.errstate(over="ignore"):
        shifted = np.maximum(values - values.max(axis=1, keepdims=True), -1)
    sorted_rows = np.sort(shifted, axis=1)[:, ::-1]
    thresholds = (np.cumsum(sorted_rows, axis=1) - 1) / np.arange(1, shifted.shape[1] + 1)
    support = np.count_nonzero(sorted_rows > thresholds, axis=1)
    threshold = thresholds[np.arange(len(shifted)), support - 1]
    return np.maximum(shifted - threshold[:, None], 0)


def score(y, y_hat):
    """Return the six sample-mean scores for matching rows of label distributions."""
    y, y_hat = (np.asarray(values, dtype=np.float64) for values in (y, y_hat))
    if y.shape != y_hat.shape or y.ndim != 2 or y.size == 0:
        raise ValueError("Expected two nonempty, identically shaped distribution matrices.")
    for distribution in (y, y_hat):
        if np.any(distribution < 0) or not np.allclose(distribution.sum(axis=1), 1, atol=1e-6, rtol=0):
            raise ValueError("Every label distribution must be nonnegative and sum to 1.")

    difference = np.abs(y - y_hat)
    total = y + y_hat
    relative = np.divide(difference, total, out=np.zeros_like(difference), where=total > 0)
    norm_product = np.linalg.norm(y, axis=1) * np.linalg.norm(y_hat, axis=1)

    # Only KL needs a positive prediction at labels that have positive target mass.
    # Leave valid finite KL terms untouched, including matching zeros.
    needs_floor = np.any((y > 0) & (y_hat == 0), axis=1)
    safe_prediction = y_hat.copy()
    smoothed = np.maximum(safe_prediction[needs_floor], KL_FLOOR)
    safe_prediction[needs_floor] = smoothed / smoothed.sum(axis=1, keepdims=True)

    return (
        float(difference.max(axis=1).mean()),
        float(np.linalg.norm(relative, axis=1).mean()),
        float(relative.sum(axis=1).mean()),
        float(np.maximum(rel_entr(y, safe_prediction).sum(axis=1), 0).mean()),
        float(np.clip((y * y_hat).sum(axis=1) / norm_product, 0, 1).mean()),
        float(np.minimum(y, y_hat).sum(axis=1).mean()),
    )
