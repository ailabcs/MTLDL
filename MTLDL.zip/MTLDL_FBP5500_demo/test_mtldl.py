from dataclasses import replace
import json
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

import numpy as np
from scipy.io import savemat

from InitSandUpdateS import compute_S


def example_tasks():
    from LoadDataSet import Task

    rng = np.random.default_rng(45)
    tasks = []
    for name, count in (("first", 21), ("second", 23)):
        x = rng.normal(size=(count, 3))
        positive = 0.2 + 0.6 / (1 + np.exp(-x[:, 0] - x[:, 1]))
        tasks.append(Task(name, x, np.column_stack((positive, 1 - positive))))
    return tuple(tasks)


def pairwise_loss(x, y, q, p, wc, wt, s, parameters):
    """Evaluate the Q/P-dependent terms of Eq. (5) directly on sample pairs."""
    z = x @ (q.T @ wc + p.T @ wt)
    phi = np.column_stack((x @ q.T, x @ p.T))
    loss = parameters.c * np.sum((z - y) ** 2)
    for i in range(len(x)):
        for j in range(len(x)):
            loss += s[i, j] * (
                parameters.beta1 * np.sum((z[i] - z[j]) ** 2)
                + parameters.beta2 * np.sum((phi[i] - phi[j]) ** 2)
            )
    return loss


class OptimizationTests(unittest.TestCase):
    def test_similarity_minimizer_includes_diagonal(self):
        distances = np.array([[0, 0.5, 4], [0.5, 0, 2], [4, 2, 0]])
        expected = [[0.625, 0.375, 0], [0.375, 0.625, 0], [0, 0, 1]]
        np.testing.assert_allclose(compute_S(distances, 1), expected)

    def test_mapping_gradients_match_eq5_for_unequal_subspaces(self):
        from mtldl import Parameters, mapping_gradient
        from InitSandUpdateS import graph_scatter

        x = np.array([[1.0, 0.2, -0.5], [0, 0.3, 0.8], [0.3, 1, 0.2]])
        y = np.array([[0.7, 0.3], [0.2, 0.8], [0.5, 0.5]])
        q = np.array([[0.8, 0.6, 0]])
        p = np.array([[0.6, 0, 0.8], [0, 1, 0]])
        wc = np.array([[0.3, -0.1]])
        wt = np.array([[0.3, 0.6], [0.4, 0.2]])
        s = np.array([[0.6, 0.4, 0], [0, 0.3, 0.7], [0.1, 0, 0.9]])
        params = Parameters(c=0.4, beta1=0.3, beta2=0.2)
        graph = graph_scatter(x, s)
        gram = params.c * (x.T @ x) + 2 * params.beta1 * graph
        target = params.c * (y.T @ x)
        coefficients = q.T @ wc + p.T @ wt
        for mapping, weight in ((q, wc), (p, wt)):
            actual = mapping_gradient(mapping, weight, coefficients, gram, target, graph, params.beta2)
            expected = np.empty_like(mapping)
            for idx in np.ndindex(mapping.shape):
                value = mapping[idx]
                mapping[idx] = value + 1e-6
                high = pairwise_loss(x, y, q, p, wc, wt, s, params)
                mapping[idx] = value - 1e-6
                low = pairwise_loss(x, y, q, p, wc, wt, s, params)
                mapping[idx] = value
                expected[idx] = (high - low) / 2e-6
            np.testing.assert_allclose(actual, expected, atol=1e-8)

    def test_fit_matches_eq5_and_solves_w_normal_equations(self):
        from mtldl import Parameters, fit

        tasks = example_tasks()
        params = Parameters(c=0.4, beta1=0.3, beta2=0.2, beta3=0.05,
                            shared_dim=1, task_dim=2, max_iterations=2, tolerance=0)
        result = fit(tasks, params, seed=12)
        model = result.model
        w = model.W
        system = np.eye(5)
        rhs = np.zeros((5, 2))
        expected_loss = np.sum(w ** 2)
        np.testing.assert_allclose(model.Q @ model.Q.T, np.eye(1), atol=1e-12)
        for t, (task, p, s) in enumerate(zip(tasks, model.P, result.similarities)):
            x, y = task.features, task.labels
            phi = np.zeros((len(x), 5))
            phi[:, :1] = x @ model.Q.T
            phi[:, 1 + 2 * t:3 + 2 * t] = x @ p.T
            np.testing.assert_allclose(p @ p.T, np.eye(2), atol=1e-12)
            np.testing.assert_allclose(s.sum(axis=1), 1, atol=1e-12)
            self.assertGreaterEqual(s.min(), 0)
            np.testing.assert_allclose(model.predict_raw(t, x), phi @ w, atol=1e-12)
            np.testing.assert_allclose(model.predict(t, x).sum(axis=1), 1, atol=1e-12)

            system += params.c * (phi.T @ phi)
            rhs += params.c * (phi.T @ y)
            expected_loss += params.c * np.sum((phi @ w - y) ** 2) + params.alpha * np.sum(s ** 2)
            for i in range(len(x)):
                for j in range(len(x)):
                    difference = phi[i] - phi[j]
                    system += params.beta1 * s[i, j] * np.outer(difference, difference)
                    expected_loss += s[i, j] * (
                        params.beta1 * np.sum((difference @ w) ** 2)
                        + params.beta2 * np.sum(difference ** 2)
                        + params.beta3 * np.sum((x[i] - x[j]) ** 2)
                    )
        np.testing.assert_allclose(system @ w, rhs, atol=1e-10)
        self.assertAlmostEqual(result.losses[-1], expected_loss, places=10)

    def test_ablations_remove_only_the_specified_terms_or_branches(self):
        from mtldl import Parameters, fit

        tasks = example_tasks()
        params = Parameters(shared_dim=1, task_dim=2, max_iterations=2)
        q_removed = fit(tasks, params, ablation="q")
        p_removed = fit(tasks, params, ablation="p")
        self.assertFalse(np.any(q_removed.model.Q))
        self.assertTrue(any(np.any(p) for p in q_removed.model.P))
        self.assertTrue(np.any(p_removed.model.Q))
        self.assertFalse(any(np.any(p) for p in p_removed.model.P))
        for term in ("beta1", "beta2", "beta3"):
            ablated = fit(tasks, params, ablation=term)
            zeroed = fit(tasks, replace(params, **{term: 0.0}))
            np.testing.assert_allclose(ablated.model.W, zeroed.model.W)


class ExperimentTests(unittest.TestCase):
    def test_each_sample_is_held_out_once_in_its_own_task(self):
        from LoadDataSet import task_folds

        tasks = example_tasks()
        folds = list(task_folds(tasks, 10, seed=42))
        self.assertEqual(len(folds), 10)
        for i, task in enumerate(tasks):
            test_indices = []
            for fold in folds:
                train, test = fold[i]
                self.assertEqual(len(np.intersect1d(train, test)), 0)
                self.assertEqual(len(train) + len(test), len(task.features))
                test_indices.extend(test)
            self.assertEqual(sorted(test_indices), list(range(len(task.features))))

    def test_nested_selection_never_uses_outer_test_labels(self):
        from LoadDataSet import Task, task_folds
        from experiment import cross_validate
        from mtldl import Parameters

        tasks = example_tasks()
        fold = next(task_folds(tasks, 10, seed=9))
        modified = []
        for task, (_, test) in zip(tasks, fold):
            changed_labels = task.labels.copy()
            changed_labels[test] = changed_labels[test, ::-1]
            modified.append(Task(task.name, task.features, changed_labels))
        parameters = Parameters(shared_dim=2, task_dim=2, max_iterations=1)
        grid = ((0.1, 1), (0.1,), (0.01,))
        original = cross_validate(tasks, parameters, seed=9, tune_grid=grid, inner_folds=2)["folds"][0]
        changed = cross_validate(tuple(modified), parameters, seed=9, tune_grid=grid, inner_folds=2)["folds"][0]
        self.assertEqual(len(original["selection"]), 2)
        self.assertEqual(original["selection"], changed["selection"])
        self.assertEqual(original["parameters"], changed["parameters"])
        self.assertEqual(original["training_loss"], changed["training_loss"])
        self.assertNotEqual(original["scores"]["ALL"]["kl"], changed["scores"]["ALL"]["kl"])

    def test_cli_writes_fold_metrics_summary_and_convergence(self):
        tasks = example_tasks()
        with tempfile.TemporaryDirectory() as directory:
            data = Path(directory) / "sample data.mat"
            output = Path(directory) / "results.json"
            savemat(data, {
                "features": np.vstack([task.features for task in tasks]),
                "labels": np.vstack([task.labels for task in tasks]),
            })
            process = subprocess.run(
                [sys.executable, "-B", str(Path(__file__).with_name("train.py")), "--data", str(data),
                 "--dataset", "custom", "--task-sizes", "21", "23", "--dimension", "2",
                 "--max-iterations", "2", "--convergence", "--output", str(output)],
                capture_output=True, text=True, timeout=30,
            )
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            results = json.loads(output.read_text(encoding="utf-8"))
        self.assertEqual(set(results["summary"]), {"task_1", "task_2", "ALL"})
        self.assertEqual(len(results["folds"]), 10)
        self.assertEqual(len(results["convergence"]), 2)
        for fold in results["folds"]:
            scores = fold["scores"]
            sizes = [scores[name]["n"] for name in ("task_1", "task_2")]
            expected = np.average([scores["task_1"]["kl"], scores["task_2"]["kl"]], weights=sizes)
            self.assertAlmostEqual(scores["ALL"]["kl"], expected)
        values = [fold["scores"]["ALL"]["kl"] for fold in results["folds"]]
        self.assertAlmostEqual(results["summary"]["ALL"]["kl"]["mean"], np.mean(values))
        self.assertAlmostEqual(results["summary"]["ALL"]["kl"]["std"], np.std(values, ddof=1))


class MetricTests(unittest.TestCase):
    def test_six_metrics_use_the_table_ii_definitions(self):
        from ldl_metrics import score

        y = np.array([[0.5, 0.5, 0]])
        y_hat = np.array([[0.25, 0.75, 0]])
        expected = (
            0.25, np.sqrt(1 / 9 + 1 / 25), 1 / 3 + 1 / 5, 0.5 * np.log(4 / 3),
            0.5 / np.sqrt(0.5 * 0.625), 0.75,
        )
        np.testing.assert_allclose(score(y, y_hat), expected, atol=1e-9)

    def test_integer_one_hot_distributions_have_finite_metrics(self):
        from ldl_metrics import score

        expected = (1, np.sqrt(2), 2, np.log(1e10), 0, 0)
        np.testing.assert_allclose(score([[1, 0]], [[0, 1]]), expected, atol=1e-9)


class DemoDatasetTests(unittest.TestCase):
    def test_fbp5500_is_the_only_predefined_dataset(self):
        from LoadDataSet import PAPER_DATASETS
        from train import BUNDLED_DATASETS, _parser

        self.assertEqual(set(PAPER_DATASETS), {"fbp5500"})
        self.assertEqual(set(BUNDLED_DATASETS), {"fbp5500"})
        self.assertEqual(_parser().parse_args([]).dataset, "fbp5500")

    def test_removed_dataset_names_are_rejected_before_reading_files(self):
        from LoadDataSet import load_dataset

        with patch("LoadDataSet.loadmat") as read_mat:
            for dataset in ("raf-ml", "scut-fbp"):
                with self.subTest(dataset=dataset), self.assertRaisesRegex(ValueError, "Unknown dataset"):
                    load_dataset(Path("unused.mat"), dataset)
            read_mat.assert_not_called()


if __name__ == "__main__":
    unittest.main()
