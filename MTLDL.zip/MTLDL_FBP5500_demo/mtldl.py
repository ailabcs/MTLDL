"""MTLDL alternating optimization for the objective in Eq. (5)."""

from dataclasses import dataclass, replace

import numpy as np
from scipy.linalg import solve

from InitSandUpdateS import compute_S, graph_scatter, init_S_matrix, squared_distances
from ldl_metrics import proj


STEP_SIZE = 0.1  # Eqs. (13) and (19).
ABLATIONS = ("q", "p", "beta1", "beta2", "beta3")


@dataclass(frozen=True)
class Parameters:
    c: float = 1.0
    alpha: float = 1.0
    beta1: float = 0.1
    beta2: float = 0.1
    beta3: float = 0.1
    shared_dim: int = 50
    task_dim: int = 50
    max_iterations: int = 10
    tolerance: float = 1e-4

    def __post_init__(self):
        weights = (self.c, self.alpha, self.beta1, self.beta2, self.beta3)
        if not np.isfinite(weights).all() or self.c <= 0 or self.alpha <= 0 or min(weights) < 0:
            raise ValueError("C and alpha must be positive, and the betas finite and nonnegative.")
        if min(self.shared_dim, self.task_dim, self.max_iterations) < 1:
            raise ValueError("Subspace dimensions and the iteration limit must be positive.")
        if not np.isfinite(self.tolerance) or self.tolerance < 0:
            raise ValueError("Tolerance must be finite and nonnegative.")

    def for_ablation(self, ablation):
        if ablation is None or ablation in ("q", "p"):
            return self
        if ablation not in ABLATIONS:
            raise ValueError(f"Unknown ablation: {ablation}")
        return replace(self, **{ablation: 0.0})


@dataclass(frozen=True)
class Model:
    Q: np.ndarray
    P: tuple[np.ndarray, ...]
    W: np.ndarray

    def predict_raw(self, task, features):
        """Return Eq. (1) and Eq. (2) applied to row samples."""
        mc = self.Q.shape[0]
        start = mc + sum(p.shape[0] for p in self.P[:task])
        p = self.P[task]
        return (features @ self.Q.T) @ self.W[:mc] + (features @ p.T) @ self.W[start:start + len(p)]

    def predict(self, task, features):
        """Return the probability distributions used for Table II scoring."""
        return proj(self.predict_raw(task, features))


@dataclass(frozen=True)
class FitResult:
    model: Model
    similarities: tuple[np.ndarray, ...]
    losses: tuple[float, ...]
    iterates: tuple[Model, ...]


def _orthogonalize(mapping):
    left, _, right = np.linalg.svd(mapping, full_matrices=False)
    return left @ right


def _compute_m_t(q, p_t, w_c, w_t, gram_t, target_t):
    """Build the shared matrix M_t used in both Q and P_t gradients.

    With row-wise input X_t and label matrix D_t, define
      G_t = X_t.T @ L_t @ X_t,
      A_t = C * X_t.T @ X_t + 2 * beta1 * G_t,
      B_t = C * D_t.T @ X_t,
      M_t = (w_c.T @ Q + w_t.T @ P_t) @ A_t - B_t.
    The dimensions are M_t: (num_labels, num_features). The graph
    Laplacian L_t uses (S_t + S_t.T)/2, matching ordered pairs in Eq. (5).
    """
    return (w_c.T @ q + w_t.T @ p_t) @ gram_t - target_t


def _gradient_from_m_t(mapping, weight, m_t, graph_t, beta2):
    """Exact Euclidean gradient: 2 * weight @ M_t + 4*beta2*mapping@G_t."""
    return 2 * (weight @ m_t + 2 * beta2 * (mapping @ graph_t))


def mapping_gradient(mapping, weight, coefficients, gram, target, graph, beta2):
    """Backward-compatible single-task gradient, expressed through M_t.

    Kept for existing callers and finite-difference tests; the training loop
    constructs M_t explicitly and shares it between the Q/P_t updates.
    """
    m_t = coefficients.T @ gram - target
    return _gradient_from_m_t(mapping, weight, m_t, graph, beta2)


def _solve_weights(q, p_list, grams, targets, rows):
    """Solve Eq. (26) with the Laplacian of the symmetric edge weights."""
    weight_dim = rows[-1][-1] + 1
    system = np.eye(weight_dim)
    rhs = np.zeros((weight_dim, targets[0].shape[0]))
    for p, gram, target, indices in zip(p_list, grams, targets, rows):
        maps = np.vstack((q, p))
        system[np.ix_(indices, indices)] += (maps @ gram) @ maps.T
        rhs[indices] += maps @ target.T
    return solve(system, rhs, assume_a="pos")


def _objective(x_list, y_list, q, p_list, weights, similarities, graphs, raw_distances, rows, params):
    loss = np.vdot(weights, weights)
    for x, y, p, s, graph, raw, indices in zip(
        x_list, y_list, p_list, similarities, graphs, raw_distances, rows
    ):
        maps = np.vstack((q, p))
        coefficients = maps.T @ weights[indices]
        residual = x @ coefficients - y
        loss += params.c * np.vdot(residual, residual)
        loss += params.alpha * np.vdot(s, s)
        # The ordered-pair sum in Eq. (5) is twice the symmetric Laplacian trace.
        loss += 2 * params.beta1 * np.sum(coefficients * (graph @ coefficients))
        loss += 2 * params.beta2 * np.sum(maps * (maps @ graph))
        loss += params.beta3 * np.einsum("ij,ij->", s, raw)
    return float(loss)


def fit(tasks, params=Parameters(), *, seed=0, ablation=None, keep_iterates=False):
    """Fit one model using labeled training tasks only, in Algorithm 1 order."""
    params = params.for_ablation(ablation)
    tasks = tuple(tasks)
    if not tasks:
        raise ValueError("At least one training task is required.")
    if any(np.iscomplexobj(task.features) or np.iscomplexobj(task.labels) for task in tasks):
        raise ValueError("Training features and labels must be real-valued.")
    x_list = tuple(np.asarray(task.features, dtype=np.float64) for task in tasks)
    y_list = tuple(np.asarray(task.labels, dtype=np.float64) for task in tasks)
    if any(x.ndim != 2 or y.ndim != 2 or not x.size or not y.size for x, y in zip(x_list, y_list)):
        raise ValueError("Each training task needs nonempty feature and label matrices.")
    feature_dim = x_list[0].shape[1]
    label_dim = y_list[0].shape[1]
    if max(params.shared_dim, params.task_dim) > feature_dim:
        raise ValueError(f"Subspace dimensions cannot exceed {feature_dim} input features.")
    for x, y in zip(x_list, y_list):
        if x.shape[1] != feature_dim or y.shape != (len(x), label_dim):
            raise ValueError("Training tasks must share feature and label dimensions and have paired rows.")
        if not np.isfinite(x).all() or np.any(y < 0) or not np.allclose(y.sum(axis=1), 1, atol=1e-6, rtol=0):
            raise ValueError("Training features must be finite and labels must be probability distributions.")

    mc, mt = params.shared_dim, params.task_dim
    weight_dim = mc + mt * len(tasks)
    rows = tuple(np.r_[0:mc, mc + t * mt:mc + (t + 1) * mt] for t in range(len(tasks)))

    rng = np.random.default_rng(seed)
    q = _orthogonalize(rng.standard_normal((mc, feature_dim)))
    p_list = tuple(_orthogonalize(rng.standard_normal((mt, feature_dim))) for _ in tasks)
    weights = rng.standard_normal((weight_dim, label_dim)) / np.sqrt(weight_dim + label_dim)
    if ablation == "q":
        q.fill(0)
    if ablation == "p":
        for p in p_list:
            p.fill(0)

    raw_distances = tuple(squared_distances(x) for x in x_list)
    similarities = tuple(init_S_matrix(raw) for raw in raw_distances)
    graphs = tuple(graph_scatter(x, s) for x, s in zip(x_list, similarities))
    supervised_grams = tuple(params.c * (x.T @ x) for x in x_list)
    targets = tuple(params.c * (y.T @ x) for x, y in zip(x_list, y_list))
    losses = []
    iterates = []
    for iteration in range(1, params.max_iterations + 1):
        grams = tuple(base + 2 * params.beta1 * graph for base, graph in zip(supervised_grams, graphs))
        shared_weight = weights[:mc]
        task_weights = tuple(weights[mc + t * mt:mc + (t + 1) * mt] for t in range(len(tasks)))

        # M_t is shared by the Q and P_t gradient formulas. Compute it once
        # at the start of each alternating iteration, never over (i, j) pairs.
        m_matrices = tuple(
            _compute_m_t(q, p, shared_weight, weight, gram, target)
            for p, weight, gram, target in zip(p_list, task_weights, grams, targets)
        )

        if ablation != "q":
            # dL/dQ = 2*w_c*sum_t(M_t) + 4*beta2*Q*sum_t(G_t).
            # Accumulate the task statistics before multiplying by Q/w_c.
            summed_m = np.sum(m_matrices, axis=0)
            if params.beta2:
                summed_graph = np.sum(graphs, axis=0)
                gradient_q = 2 * (shared_weight @ summed_m + 2 * params.beta2 * (q @ summed_graph))
            else:
                gradient_q = 2 * (shared_weight @ summed_m)
            old_q = q
            q = _orthogonalize(q - STEP_SIZE * gradient_q)

            if ablation != "p":
                # The Q update changes M_t, but P_t and W are still fixed.
                # Refresh M_t using the exact rank-limited correction instead
                # of rebuilding the complete coefficient matrix for each task:
                # M_t(new Q) = M_t(old Q) + w_c.T @ (new Q - old Q) @ A_t.
                shared_change = shared_weight.T @ (q - old_q)
                m_matrices = tuple(
                    m_t + shared_change @ gram
                    for m_t, gram in zip(m_matrices, grams)
                )

        if ablation != "p":
            updated = []
            for p, weight, m_t, graph in zip(p_list, task_weights, m_matrices, graphs):
                gradient_p = _gradient_from_m_t(p, weight, m_t, graph, params.beta2)
                updated.append(_orthogonalize(p - STEP_SIZE * gradient_p))
            p_list = tuple(updated)

        updated_similarities = []
        for x, p, raw, indices in zip(x_list, p_list, raw_distances, rows):
            embedded = x @ np.vstack((q, p)).T
            cost = params.beta3 * raw
            if params.beta1:
                cost += params.beta1 * squared_distances(embedded @ weights[indices])
            if params.beta2:
                cost += params.beta2 * squared_distances(embedded)
            updated_similarities.append(compute_S(cost, params.alpha))
        similarities = tuple(updated_similarities)
        graphs = tuple(graph_scatter(x, s) for x, s in zip(x_list, similarities))
        grams = tuple(base + 2 * params.beta1 * graph for base, graph in zip(supervised_grams, graphs))
        weights = _solve_weights(q, p_list, grams, targets, rows)
        loss = _objective(x_list, y_list, q, p_list, weights, similarities, graphs, raw_distances, rows, params)
        if not np.isfinite(loss):
            raise FloatingPointError(f"Nonfinite objective at iteration {iteration}. Check the feature scale.")
        losses.append(loss)

        if keep_iterates:
            iterates.append(Model(q, p_list, weights))
        if params.tolerance > 0 and len(losses) > 1:
            previous = losses[-2]
            if abs(loss - previous) <= params.tolerance * max(1, abs(previous)):
                break

    return FitResult(Model(q, p_list, weights), similarities, tuple(losses), tuple(iterates))
