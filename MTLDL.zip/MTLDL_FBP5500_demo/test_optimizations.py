"""Regression checks for the Duchi simplex update and M_t gradient reuse."""
import unittest

import numpy as np
from scipy.optimize import minimize

from InitSandUpdateS import compute_S, graph_scatter
from ldl_metrics import proj
from mtldl import _compute_m_t, _gradient_from_m_t, mapping_gradient


class ExactSimplexTests(unittest.TestCase):
    def test_blocked_projection_matches_unblocked_duchi(self):
        rng = np.random.default_rng(2026)
        for alpha in (0.01, 0.7, 100):
            cost = rng.uniform(0, 10, size=(271, 271))
            cost[np.arange(len(cost)), np.arange(len(cost))] = 0
            expected = proj(-cost / (2 * alpha))
            for block_rows in (1, 7, 128, 1024):
                actual = compute_S(cost, alpha, block_rows=block_rows)
                np.testing.assert_allclose(actual, expected, atol=3e-14, rtol=0)
                np.testing.assert_allclose(actual.sum(axis=1), 1, atol=3e-14, rtol=0)
                self.assertGreaterEqual(actual.min(), 0)

    def test_duchi_update_matches_constrained_qp(self):
        rng = np.random.default_rng(2025)
        n = 7
        cost = rng.uniform(0, 4, size=(n, n))
        alpha = 0.37
        actual = compute_S(cost, alpha, block_rows=2)
        bounds = [(0, None)] * n
        constraint = {"type": "eq", "fun": lambda s: s.sum() - 1,
                      "jac": lambda s: np.ones_like(s)}
        for row in range(n):
            c = cost[row]
            qp = minimize(
                lambda s: alpha * s @ s + c @ s,
                np.full(n, 1.0 / n),
                jac=lambda s: 2 * alpha * s + c,
                bounds=bounds,
                constraints=constraint,
                method="SLSQP",
                options={"maxiter": 1000, "ftol": 1e-13},
            )
            self.assertTrue(qp.success, qp.message)
            np.testing.assert_allclose(actual[row], qp.x, atol=1e-7, rtol=0)
            self.assertLessEqual(alpha * actual[row] @ actual[row] + c @ actual[row],
                                 qp.fun + 1e-10)


class MMatrixGradientTests(unittest.TestCase):
    def test_m_matrix_and_q_update_agree_with_original_gradient(self):
        rng = np.random.default_rng(21)
        n, d, c, m, k = 19, 9, 3, 4, 5
        q = rng.normal(size=(c, d))
        w_c = rng.normal(size=(c, k))
        p_list = [rng.normal(size=(m, d)) for _ in range(3)]
        w_list = [rng.normal(size=(m, k)) for _ in range(3)]
        graphs, grams, targets, m_list = [], [], [], []
        beta1, beta2, reg_c = 0.3, 0.4, 0.9
        for p, w in zip(p_list, w_list):
            x = rng.normal(size=(n, d))
            labels = rng.normal(size=(n, k))
            similarity = rng.random((n, n))
            similarity /= similarity.sum(axis=1, keepdims=True)
            graph = graph_scatter(x, similarity)
            gram = reg_c * x.T @ x + 2 * beta1 * graph
            target = reg_c * labels.T @ x
            m_t = _compute_m_t(q, p, w_c, w, gram, target)
            coefficients = q.T @ w_c + p.T @ w
            np.testing.assert_allclose(m_t, coefficients.T @ gram - target, atol=1e-12)
            graphs.append(graph)
            grams.append(gram)
            targets.append(target)
            m_list.append(m_t)

        aggregate = 2 * (w_c @ np.sum(m_list, axis=0)
                         + 2 * beta2 * q @ np.sum(graphs, axis=0))
        original = sum((mapping_gradient(q, w_c, q.T @ w_c + p.T @ w,
                                         gram, target, graph, beta2)
                        for p, w, gram, target, graph in zip(
                            p_list, w_list, grams, targets, graphs)),
                       np.zeros_like(q))
        np.testing.assert_allclose(aggregate, original, atol=1e-10)

        new_q = q + rng.normal(scale=0.02, size=q.shape)
        change = w_c.T @ (new_q - q)
        for p, w, gram, target, graph, m_t in zip(
            p_list, w_list, grams, targets, graphs, m_list
        ):
            refreshed = m_t + change @ gram
            direct = _compute_m_t(new_q, p, w_c, w, gram, target)
            np.testing.assert_allclose(refreshed, direct, atol=1e-11)
            np.testing.assert_allclose(
                _gradient_from_m_t(p, w, refreshed, graph, beta2),
                mapping_gradient(p, w, new_q.T @ w_c + p.T @ w,
                                 gram, target, graph, beta2),
                atol=1e-10,
            )


if __name__ == "__main__":
    unittest.main()
