"""Ten-fold evaluation with optional model selection inside each training fold."""

from dataclasses import asdict, replace
from itertools import product

import numpy as np

from LoadDataSet import task_folds
from ldl_metrics import KL_FLOOR, METRICS, score
from mtldl import STEP_SIZE, fit


OUTER_FOLDS = 10
PAPER_GRID = tuple(10.0 ** exponent for exponent in range(-3, 4))
GRID_NAMES = ("c", "beta1", "beta3")


def _split_tasks(tasks, splits):
    training = tuple(task.subset(train) for task, (train, _) in zip(tasks, splits))
    held_out = tuple(task.subset(test) for task, (_, test) in zip(tasks, splits))
    return training, held_out


def _evaluate(model, tasks):
    values = [score(task.labels, model.predict(t, task.features)) for t, task in enumerate(tasks)]
    sizes = [len(task.features) for task in tasks]
    pooled = np.average(values, weights=sizes, axis=0).tolist()
    return {
        name: {"n": count, **dict(zip(METRICS, scores))}
        for name, count, scores in zip(
            [task.name for task in tasks] + ["ALL"], sizes + [sum(sizes)], values + [pooled]
        )
    }


def _evaluate_kl(model, tasks):
    # KL is a mean of per-sample values. Pool across tasks with their sample counts.
    return _evaluate(model, tasks)["ALL"]["kl"]


def _candidates(params, grid, ablation):
    if len(grid) != len(GRID_NAMES) or any(len(values) == 0 for values in grid):
        raise ValueError("Provide nonempty grids for C, beta1 and beta3.")
    values = [
        (0.0,) if name == ablation else sorted(set(candidates))
        for name, candidates in zip(GRID_NAMES, grid)
    ]
    return tuple(replace(params, **dict(zip(GRID_NAMES, point))) for point in product(*values))


def _select_parameters(training, candidates, inner_folds, seed, ablation):
    validation_kl = np.zeros(len(candidates))
    for k, splits in enumerate(task_folds(training, inner_folds, seed=seed), start=1):
        inner_train, validation = _split_tasks(training, splits)
        for i, params in enumerate(candidates):
            model = fit(inner_train, params, seed=seed + k, ablation=ablation).model
            validation_kl[i] += _evaluate_kl(model, validation)
    validation_kl /= inner_folds
    scores = [
        {name: getattr(params, name) for name in GRID_NAMES} | {"validation_kl": float(kl)}
        for params, kl in zip(candidates, validation_kl)
    ]
    return candidates[int(np.argmin(validation_kl))], scores


def _statistics(values):
    return {"mean": float(np.mean(values)), "std": float(np.std(values, ddof=1))}


def cross_validate(tasks, params, *, seed=0, tune_grid=None, inner_folds=3, ablation=None,
                   convergence=False, on_fold=None):
    """Return fold scores, sample indices, selected settings and mean/std by task."""
    tasks = tuple(tasks)
    names = [task.name for task in tasks]
    if not names or len(set(names)) != len(names) or "ALL" in names:
        raise ValueError("Use at least one task with unique names. 'ALL' is reserved.")
    params = params.for_ablation(ablation)
    if convergence:
        params = replace(params, tolerance=0)
    candidates = _candidates(params, tune_grid, ablation) if tune_grid is not None else None
    if candidates is not None and inner_folds < 2:
        raise ValueError("Parameter selection requires at least two inner folds.")

    seed_streams = np.random.SeedSequence(seed).spawn(OUTER_FOLDS)
    records = []
    for k, splits in enumerate(task_folds(tasks, OUTER_FOLDS, seed=seed), start=1):
        training, holdout = _split_tasks(tasks, splits)
        fit_seed, tune_seed = map(int, seed_streams[k - 1].generate_state(2))
        if on_fold is not None:
            on_fold(k, OUTER_FOLDS)

        chosen = params
        selection = None
        if candidates is not None:
            chosen, selection = _select_parameters(training, candidates, inner_folds, tune_seed, ablation)

        fitted = fit(training, chosen, seed=fit_seed, ablation=ablation, keep_iterates=convergence)
        record = {
            "fold": k,
            "fit_seed": fit_seed,
            "parameters": asdict(chosen),
            "test_indices": {task.name: test.tolist() for task, (_, test) in zip(tasks, splits)},
            "training_loss": fitted.losses,
            "scores": _evaluate(fitted.model, holdout),
        }
        if selection is not None:
            record["tuning_seed"] = tune_seed
            record["selection"] = selection
        if convergence:
            record["convergence_kl"] = [_evaluate_kl(model, holdout) for model in fitted.iterates]
        records.append(record)

    summary = {
        name: {metric: _statistics([fold["scores"][name][metric] for fold in records]) for metric in METRICS}
        for name in names + ["ALL"]
    }
    results = {
        "seed": seed,
        "ablation": ablation or "full",
        "outer_folds": OUTER_FOLDS,
        "inner_folds": inner_folds if candidates is not None else None,
        "step_size": STEP_SIZE,
        "kl_floor": KL_FLOOR,
        "folds": records,
        "summary": summary,
    }
    if convergence:
        results["convergence"] = [
            {"iteration": i + 1, "kl": _statistics([fold["convergence_kl"][i] for fold in records])}
            for i in range(params.max_iterations)
        ]
    return results
