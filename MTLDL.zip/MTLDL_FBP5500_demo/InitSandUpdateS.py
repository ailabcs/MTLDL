"""Within-task graph operations for Eqs. (21)–(26)."""

import numpy as np

from ldl_metrics import proj


def squared_distances(x):
    centered = x - x.mean(axis=0)
    squared_norms = np.einsum("ij,ij->i", centered, centered)
    distances = centered @ centered.T
    distances *= -2
    distances += squared_norms[:, None]
    distances += squared_norms[None, :]
    np.maximum(distances, 0, out=distances)
    np.fill_diagonal(distances, 0)
    return distances


def init_S_matrix(distances, sigma=512.0):
    """Retain the original Gaussian initialization with the paper's row constraints."""
    weights = np.exp(-distances / (2 * sigma))
    return weights / weights.sum(axis=1, keepdims=True)


def compute_S(cost, alpha, *, block_rows=256):
    """Exact row-wise S update by Duchi's sort-based simplex projection.

    For every row i, Eq. (23) is
        min_{s >= 0, sum(s) = 1} alpha * ||s||_2**2 + cost[i] @ s.
    Completing the square gives the Euclidean simplex projection of
        v = -cost[i] / (2 * alpha).
    Duchi et al. (ICML 2008) solve it via sorting and a support threshold;
    `proj` implements that algorithm. No general-purpose QP solver is used.

    Processing independent rows in bounded-size blocks prevents sorting from
    allocating several additional n-by-n arrays at once. The diagonal entries
    remain eligible, exactly as in the paper's constraint set.
    """
    cost = np.asarray(cost, dtype=np.float64)
    if cost.ndim != 2 or cost.shape[0] != cost.shape[1] or cost.shape[0] == 0:
        raise ValueError("S costs must be a nonempty square matrix.")
    if not np.isfinite(alpha) or alpha <= 0:
        raise ValueError("S requires a positive, finite alpha.")
    if not isinstance(block_rows, int) or block_rows <= 0:
        raise ValueError("block_rows must be a positive integer.")

    similarity = np.empty_like(cost)
    for start in range(0, len(cost), block_rows):
        stop = min(start + block_rows, len(cost))
        similarity[start:stop] = proj(-cost[start:stop] / (2.0 * alpha))
    return similarity


def graph_scatter(x, similarity):
    """Return X.T @ L @ X for row samples, using the symmetric edge weights."""
    adjacency = (similarity + similarity.T) * 0.5
    centered = x - x.mean(axis=0)
    laplacian_x = adjacency.sum(axis=1, keepdims=True) * centered - adjacency @ centered
    scatter = centered.T @ laplacian_x
    return (scatter + scatter.T) * 0.5
