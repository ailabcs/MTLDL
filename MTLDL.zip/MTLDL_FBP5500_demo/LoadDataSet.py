"""Read the precomputed feature and distribution matrices and split each task."""

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy.io import loadmat
from scipy.sparse import issparse


# The FBP5500 demo uses these contiguous task blocks in MAT row order.
PAPER_DATASETS = {
    "fbp5500": ({"AF": 2000, "AM": 2000, "CF": 750, "CM": 750}, 256, 5),
}


@dataclass(frozen=True)
class Task:
    name: str
    features: np.ndarray  # (samples, feature dimension)
    labels: np.ndarray    # (samples, label dimension)

    def subset(self, indices):
        return Task(self.name, self.features[indices], self.labels[indices])


def _read_matrix(data, name):
    if name not in data:
        raise ValueError(f"The MAT file must contain a '{name}' matrix.")
    values = data[name]
    if issparse(values):
        values = values.toarray()
    if values.ndim != 2 or values.size == 0 or values.dtype.kind not in "biuf":
        raise ValueError(f"'{name}' must be a nonempty two-dimensional real numeric matrix.")
    values = np.asarray(values, dtype=np.float64)
    if not np.isfinite(values).all():
        raise ValueError(f"'{name}' contains NaN or infinity.")
    return values


def load_dataset(path: Path, dataset="fbp5500", *, task_names=None, task_sizes=None):
    """Load rows grouped into contiguous tasks with the same feature and label spaces."""
    if dataset != "custom" and dataset not in PAPER_DATASETS:
        raise ValueError(f"Unknown dataset: {dataset}")
    try:
        data = loadmat(path, appendmat=False, variable_names=("features", "labels"))
    except NotImplementedError as error:
        raise ValueError("Save MATLAB v7.3 data as a v7 MAT file with features and labels.") from error

    x = _read_matrix(data, "features")
    y = _read_matrix(data, "labels")
    if x.shape[0] != y.shape[0]:
        raise ValueError("'features' and 'labels' must have the same number of sample rows.")
    masses = y.sum(axis=1, keepdims=True)
    # Normalize rounding error in the stored label distributions.
    if np.any(y < 0) or not np.allclose(masses, 1, atol=1e-5, rtol=0):
        raise ValueError("Each label row must be nonnegative and sum to 1.")
    y = y / masses

    if dataset == "custom":
        if not task_sizes:
            raise ValueError("Custom datasets require --task-sizes in MAT row order.")
        names = tuple(task_names or (f"task_{i + 1}" for i in range(len(task_sizes))))
        sizes = tuple(task_sizes)
    else:
        if task_sizes is not None:
            raise ValueError("Use --dataset custom to set task sizes.")
        paper_sizes, feature_dim, label_dim = PAPER_DATASETS[dataset]
        names = tuple(task_names or paper_sizes)
        if len(names) != len(paper_sizes) or set(names) != set(paper_sizes):
            raise ValueError(f"Task names for {dataset} must list each of {', '.join(paper_sizes)} once.")
        sizes = tuple(paper_sizes[name] for name in names)
        if x.shape[1] != feature_dim or y.shape[1] != label_dim:
            raise ValueError(f"{dataset} requires {feature_dim} features and {label_dim} label columns.")

    if len(names) != len(sizes) or len(set(names)) != len(names) or "ALL" in names:
        raise ValueError("Provide one unique task name per block. 'ALL' is reserved for pooled scores.")
    if any(size < 1 for size in sizes) or sum(sizes) != len(x):
        raise ValueError(f"Task sizes must be positive and cover all {len(x)} sample rows.")
    boundaries = np.cumsum((0, *sizes))
    return tuple(
        Task(name, x[start:stop], y[start:stop])
        for name, start, stop in zip(names, boundaries[:-1], boundaries[1:])
    )


def task_folds(tasks, n_splits, *, seed):
    """Yield one (train, test) index pair per task in each seeded fold."""
    if n_splits < 2:
        raise ValueError("Cross-validation requires at least two folds.")
    rng = np.random.default_rng(seed)
    test_folds = []
    for task in tasks:
        n = len(task.features)
        if n < n_splits:
            raise ValueError(f"Task {task.name!r} has {n} samples, fewer than {n_splits} folds.")
        test_folds.append(np.array_split(rng.permutation(n), n_splits))

    for fold_tests in zip(*test_folds):
        splits = []
        for task, test in zip(tasks, fold_tests):
            test = np.sort(test)
            train_mask = np.ones(len(task.features), dtype=bool)
            train_mask[test] = False
            splits.append((np.flatnonzero(train_mask), test))
        yield tuple(splits)
