"""Standalone, single-run S timing/memory benchmark; run in a fresh process.

Use OPENBLAS_NUM_THREADS=1 for comparisons; prints process peak RSS.
"""
import resource
import time

import numpy as np
from InitSandUpdateS import compute_S


def main():
    rng = np.random.default_rng(1212)
    size = 1700
    cost = rng.uniform(0, 10, size=(size, size))
    np.fill_diagonal(cost, 0)
    before = time.perf_counter()
    similarity = compute_S(cost, 1.0)
    elapsed = time.perf_counter() - before
    print(f"size: {size} by {size}, projection time: {elapsed:.3f} seconds")
    print(f"peak RSS: {resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024:.1f} MiB")
    print(f"max row-sum error: {np.abs(similarity.sum(axis=1) - 1).max():.3g}")


if __name__ == "__main__":
    main()
