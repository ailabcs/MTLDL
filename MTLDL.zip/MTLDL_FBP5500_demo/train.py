"""Run the FBP5500 demo with task-wise ten-fold cross-validation."""

import argparse
import json
from pathlib import Path
import sys
from tempfile import NamedTemporaryFile

from numpy.linalg import LinAlgError

from LoadDataSet import PAPER_DATASETS, load_dataset
from experiment import PAPER_GRID, cross_validate
from ldl_metrics import METRICS
from mtldl import ABLATIONS, Parameters


BUNDLED_DATASETS = {
    "fbp5500": Path("dataset") / "FBP5500.mat",
}


def _parser():
    parser = argparse.ArgumentParser(description="MTLDL FBP5500 demo with task-wise ten-fold cross-validation.")
    parser.add_argument("--data", type=Path, help="Override the MAT file. Required for custom datasets.")
    parser.add_argument(
        "--dataset", type=str.lower, choices=(*PAPER_DATASETS, "custom"), default="fbp5500",
        help="Use the bundled FBP5500 demo, or supply a custom dataset (default: fbp5500).",
    )
    parser.add_argument("--task-names", nargs="+", help="Task names in the actual MAT row-block order.")
    parser.add_argument("--task-sizes", nargs="+", type=int, help="Row counts for a custom dataset.")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--dimension", type=int, default=50, help="Shared and task-specific dimensions.")
    parser.add_argument("--c", nargs="+", type=float, help="Fixed C, or candidate values with --tune.")
    parser.add_argument("--beta1", nargs="+", type=float, help="Fixed beta1, or candidates with --tune.")
    parser.add_argument("--beta3", nargs="+", type=float, help="Fixed beta3, or candidates with --tune.")
    parser.add_argument("--tune", action="store_true", help="Select C, beta1, beta3 by inner-fold KL.")
    parser.add_argument("--inner-folds", type=int, default=3, help="Training-only folds used with --tune.")
    parser.add_argument("--ablation", choices=ABLATIONS, help="Remove one branch or graph term.")
    parser.add_argument("--max-iterations", type=int, default=10)
    parser.add_argument("--tolerance", type=float, default=1e-4, help="Relative loss change. 0 disables early stopping.")
    parser.add_argument("--convergence", action="store_true", help="Run all iterations and evaluate the saved iterates.")
    parser.add_argument("--output", type=Path, help="Write detailed results to this JSON file.")
    return parser


def _save_results(path, results):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        with NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as stream:
            temp_path = Path(stream.name)
            json.dump(results, stream, ensure_ascii=False, allow_nan=False, indent=2)
            stream.write("\n")
        temp_path.replace(path)
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def _print_summary(results):
    print(f"{'task':<12}" + "".join(f"{metric:>21}" for metric in METRICS))
    for name, metrics in results["summary"].items():
        formatted = [f"{metrics[m]['mean']:.4f} +/- {metrics[m]['std']:.4f}" for m in METRICS]
        print(f"{name:<12}" + "".join(f"{value:>21}" for value in formatted))


def _fold_progress(fold, total):
    print(f"Fold {fold}/{total}", file=sys.stderr, flush=True)


def main(argv=None):
    parser = _parser()
    args = parser.parse_args(argv)
    if args.seed < 0:
        parser.error("--seed must be nonnegative.")
    if args.output is not None and args.output.suffix.lower() != ".json":
        parser.error("--output must have a .json extension.")
    if args.data is None:
        if args.dataset == "custom":
            parser.error("--dataset custom requires --data.")
        bundled_path = BUNDLED_DATASETS[args.dataset]
        data_path = Path(__file__).resolve().parent / bundled_path
        data_reference = bundled_path.as_posix()
    else:
        data_path = args.data
        data_reference = data_path.name if data_path.is_absolute() else data_path.as_posix()
    if not data_path.is_file():
        parser.error(f"Data file not found: {data_reference}")
    if args.output is not None and args.output.resolve() == data_path.resolve():
        parser.error("--output must differ from the data path.")

    fixed = (args.c or (1.0,), args.beta1 or (0.1,), args.beta3 or (0.1,))
    if not args.tune and any(len(values) != 1 for values in fixed):
        parser.error("Multiple values for C, beta1 or beta3 require --tune.")
    grid = (args.c or PAPER_GRID, args.beta1 or PAPER_GRID, args.beta3 or PAPER_GRID) if args.tune else None
    try:
        tasks = load_dataset(data_path, args.dataset, task_names=args.task_names, task_sizes=args.task_sizes)
        feature_dim = tasks[0].features.shape[1]
        params = Parameters(
            c=fixed[0][0], beta1=fixed[1][0], beta3=fixed[2][0],
            shared_dim=args.dimension, task_dim=args.dimension,
            max_iterations=args.max_iterations, tolerance=args.tolerance,
        )
        results = cross_validate(
            tasks, params, seed=args.seed, tune_grid=grid, inner_folds=args.inner_folds,
            ablation=args.ablation, convergence=args.convergence, on_fold=_fold_progress,
        )
        results["dataset"] = args.dataset
        results["data"] = data_reference
        results["feature_dim"] = feature_dim
        results["task_sizes"] = {task.name: len(task.features) for task in tasks}
        if args.output is not None:
            _save_results(args.output, results)
    except (OSError, ValueError, FloatingPointError, LinAlgError) as error:
        parser.error(str(error))
    _print_summary(results)


if __name__ == "__main__":
    main()
